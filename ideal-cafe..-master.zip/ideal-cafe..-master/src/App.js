import IdealCafe from './components/IdealCafe'; // or './IdealCafe' if not in components folder
import './App.css';


function App() {
  return (
    <div className="App">
      <IdealCafe />
    </div>
  );
}

export default App; // Must include this